import React from "react";


const Header = (props) => {

    return (
        <header>
            <h2>Всі анкети:</h2>
             <div className="flex">
                <input type="text" />
                <img src="#" alt="" />
                <select name="" id="">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                </select>
             </div>
        </header>
    )
}
export { Header }