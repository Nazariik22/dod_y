import React from "react";
import { useSelector } from "react-redux";
import { Ancet } from "./Ancet/Ancet";
import { Header } from "./Header/Header";


const Ancets = (props) => {
    const state = useSelector(state => state.ancets);
    return (
        <div>
            <Header />
            <section>
                {state.map(item =>
                    <Ancet
                        img={item.img}
                        alias={item.alias}
                        idUser={item.idUser}
                        id={item.id}
                    />
                )}
            </section>
        </div>
    )
}
export { Ancets }